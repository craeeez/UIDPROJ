# Modern-Media-Player-UI-Visual-Basic-VB.Net
<img src="https://i.ytimg.com/vi/hGRZMiPz0L4/maxresdefault.jpg">
<h1> Tutorial</h1>
https://youtu.be/hGRZMiPz0L4
