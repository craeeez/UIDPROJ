﻿Imports MySql.Data.MySqlClient
Imports System.Data

Public Class loginform
    Dim conn As MySqlConnection
    Dim cmd As New MySqlCommand
    Dim username As String = ""
    Dim password As String = ""

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        If txtusername.Text = "" Then
            MsgBox("enter username")
        ElseIf txtpassword.Text = "" Then
            MsgBox("enter password")
        Else
            conn = New MySqlConnection("Database=mediaplayer;Data Source=localhost;User Id=root;Password=")
            Dim adapter As New MySqlDataAdapter()
            Dim table As New DataTable()
            Dim Query As String = "select username,password from login where username='" & Me.txtusername.Text & "'and password='" & Me.txtpassword.Text & "';"
            cmd = New MySqlCommand(Query, conn)
            adapter.SelectCommand = cmd
            adapter.Fill(table)
            If table.Rows.Count > 0 Then
                MsgBox("login successfull")
                Dim form1 = New Form1
                form1.Show()
                Me.Hide()
            Else
                MsgBox("wrong username or password")
                txtusername.Clear()
                txtpassword.Clear()

            End If
            conn.Close()

        End If
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

    End Sub

    Private Sub btnlogin_KeyPress(sender As Object, e As KeyPressEventArgs) Handles btnlogin.KeyPress

    End Sub

    Private Sub loginform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class