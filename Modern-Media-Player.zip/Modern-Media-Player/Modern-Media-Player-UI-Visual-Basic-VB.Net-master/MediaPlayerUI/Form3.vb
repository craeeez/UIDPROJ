﻿Imports MySql.Data.MySqlClient
Imports System.Data

Public Class Form3
    Dim track As String
    Dim conn As MySqlConnection
    Dim cmd As New MySqlCommand

    Private Sub button5_Click(sender As Object, e As EventArgs) Handles button5.Click
        Me.Close()
    End Sub

    Private Sub button6_Click(sender As Object, e As EventArgs) Handles button6.Click
        ListBox1.Items.Clear()

    End Sub

    Private Sub button9_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub button7_Click(sender As Object, e As EventArgs) Handles button7.Click
        OpenFileDialog1.ShowDialog()

        For Each track In OpenFileDialog1.FileNames
            ListBox1.Items.Add(System.IO.Path.GetFileName(track))
        Next
        ListBox1.SelectedIndex = 0
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) 
        conn = New MySqlConnection("Database=mediaplayer;Data Source=localhost;User Id=root;Password=")


    End Sub
End Class